-- Generado por Oracle SQL Developer Data Modeler 23.1.0.087.0806
--   en:        2024-09-30 20:54:36 CLST
--   sitio:      Oracle Database 21c
--   tipo:      Oracle Database 21c



-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE TABLE costo_operacional (
    pago_entrenador        INTEGER,
    compras_equipos        INTEGER,
    compras_insumos        INTEGER,
    sf_solicitud_fondos_id NUMBER NOT NULL
);

CREATE TABLE escuela (
    id_escuela             INTEGER GENERATED ALWAYS AS IDENTITY,
    tipo_escuela           VARCHAR2(40 BYTE),
    detalle_ubicacion      VARCHAR2(100 BYTE),
    info_contacto          VARCHAR2(100 BYTE),
    sf_solicitud_fondos_id NUMBER NOT NULL
);

ALTER TABLE escuela ADD CONSTRAINT escuela_pk PRIMARY KEY ( id_escuela );

CREATE TABLE personal (
    nacionalidad       VARCHAR2(100 BYTE),
    id_personal        INTEGER GENERATED ALWAYS AS IDENTITY,
    nombre_funcionario VARCHAR2(30),
    id_escuela         INTEGER NOT NULL
);

ALTER TABLE personal ADD CONSTRAINT personal_pk PRIMARY KEY ( id_personal );

ALTER TABLE personal ADD CONSTRAINT perso_fun_nac_un UNIQUE ( nacionalidad,
                                                              nombre_funcionario );

CREATE TABLE solicitud_fondos (
    id_sol_fondos  NUMBER NOT NULL,
    id_solicitud   INTEGER,
    tipo_solicitud VARCHAR2(15 BYTE)
);

ALTER TABLE solicitud_fondos ADD CONSTRAINT solicitud_fondos_pk PRIMARY KEY ( id_sol_fondos );

ALTER TABLE costo_operacional
    ADD CONSTRAINT costo_ope_sol_fon_fk FOREIGN KEY ( sf_solicitud_fondos_id )
        REFERENCES solicitud_fondos ( id_sol_fondos );

ALTER TABLE escuela
    ADD CONSTRAINT escuela_solicitud_fondos_fk FOREIGN KEY ( sf_solicitud_fondos_id )
        REFERENCES solicitud_fondos ( id_sol_fondos );

ALTER TABLE personal
    ADD CONSTRAINT personal_escuela_fk FOREIGN KEY ( id_escuela )
        REFERENCES escuela ( id_escuela );

CREATE SEQUENCE solicitud_fondos_id_sol_fondos START WITH 1 NOCACHE ORDER;

CREATE OR REPLACE TRIGGER solicitud_fondos_id_sol_fondos BEFORE
    INSERT ON solicitud_fondos
    FOR EACH ROW
    WHEN ( new.id_sol_fondos IS NULL )
BEGIN
    :new.id_sol_fondos := solicitud_fondos_id_sol_fondos.nextval;
END;
/
